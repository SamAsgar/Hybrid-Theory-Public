M04 Network Citadel | AC05-G3 | PART2
Publieke tekstuitgave van de testsessie van 27 november 2026

P2 — TESTED / scoped PASS voor de vier geteste IPv4 TCP-verbindingen van één OT-client naar één monitoringserver.

Dienst                  Poort       Client       pfSense
Agentverkeer            TCP/1514    Verbonden    PASS
Agentregistratie        TCP/1515    Timeout      BLOCK
Dashboard               TCP/443     Timeout      BLOCK
API                     TCP/55000   Timeout      BLOCK

De negen bewijs-ID’s verwijzen naar samenvattingen van de oorspronkelijke beeldbeschrijvingen. Bron en bestemming zijn aangeduid met hun functie. De bestemmingspoorten zijn behouden om elke test aan de bijbehorende firewallbeslissing te kunnen koppelen.

AC05 integraal — PENDING. Agentregistratie, eventontvangst en detectie van bestandswijzigingen (FIM) vereisen afzonderlijke validatie.
